<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Olá</title>
    </head>
    <body>
        <h1>Seja bem vindo!</h1>
        <h2>Entrar como</h2>
        <a href="entrar_cliente.php"><img src="imgs/Cliente.png"></a>
        <a href="entrar_cozinheiro.php"><img src="imgs/cozinheiro.png"></a>
        <p>É novo aqui?</p>
        <a href="cadastrar_usuario.php?cod=01">Cadastre-se</a>
        <p>Quer ser um cozinheiro?</p>
        <a href="cadastrar_usuario.php?cod=02">Cadastre-se como cozinheiro</a>

        <?php
        // put your code here
        ?>
    </body>
</html>
